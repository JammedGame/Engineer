public void Closing(Game G, EventArguments E)
{
	
}