public void MouseClick(Game G, EventArguments E)
{
	MouseClickType Button = E.ButtonDown;
	Vertex Location = E.Location;
}