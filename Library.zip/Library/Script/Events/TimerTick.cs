public void TimerTick(Game G, EventArguments E)
{
	
}