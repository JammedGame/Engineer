public void KeyDown(Game G, EventArguments E)
{
	KeyType Key = E.KeyDown;
	bool Ctrl = E.Control;
	bool Alt = E.Alt;
	bool Shift = E.Shift;
}