public void MouseUp(Game G, EventArguments E)
{
	MouseClickType Button = E.ButtonDown;
	Vertex Location = E.Location;
}