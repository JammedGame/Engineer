public void MouseWheel(Game G, EventArguments E)
{
	int Delta = E.Delta;
}