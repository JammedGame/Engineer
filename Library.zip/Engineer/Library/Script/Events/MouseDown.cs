public void MouseDown(Game G, EventArguments E)
{
	MouseClickType Button = E.ButtonDown;
	Vertex Location = E.Location;
}