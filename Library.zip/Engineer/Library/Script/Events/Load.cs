public void Load(Game G, EventArguments E)
{
	
}